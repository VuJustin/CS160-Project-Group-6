export const PORT = 5555;

export const mongoDBURL = 'mongodb+srv://root:root@media-library.cu5npcb.mongodb.net/books-collection?retryWrites=true&w=majority&appName=Media-Library'